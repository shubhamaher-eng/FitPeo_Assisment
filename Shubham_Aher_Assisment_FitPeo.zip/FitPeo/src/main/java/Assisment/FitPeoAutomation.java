package Assisment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class FitPeoAutomation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Step 1: Navigate to the FitPeo Homepage
            driver.get("https://www.fitpeo.com");

            // Step 2: Navigate to the Revenue Calculator Page
            WebElement revenueCalculatorLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Revenue Calculator")));
            revenueCalculatorLink.click();

            // Step 3: Scroll to the Slider section
            WebElement sliderSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("revenue-calculator-slider-id")));
            ((ChromeDriver) driver).executeScript("arguments[0].scrollIntoView(true);", sliderSection);

            // Step 4: Adjust the slider to set its value to 820
            WebElement slider = driver.findElement(By.xpath("xpath_to_slider"));
            Actions move = new Actions(driver);
            move.clickAndHold(slider).moveByOffset(820, 0).release().perform();
            Thread.sleep(1000); // Wait for the value to update

            // Validate slider value
            WebElement sliderValue = driver.findElement(By.xpath("xpath_to_slider_value"));
            assert sliderValue.getAttribute("value").equals("820");

            // Step 5: Update the text field with the value 560
            WebElement textField = driver.findElement(By.xpath("xpath_to_text_field"));
            textField.click();
            textField.clear();
            textField.sendKeys("560");
            Thread.sleep(1000); // Wait for the slider to update

            // Validate slider position
            assert sliderValue.getAttribute("value").equals("560");

            // Step 6: Select the specified CPT codes
            List<String> cptCodes = List.of("99091", "99453", "99454", "99474");
            for (String code : cptCodes) {
                WebElement checkbox = driver.findElement(By.xpath("//input[@value='CPT-" + code + "']"));
                if (!checkbox.isSelected()) {
                    checkbox.click();
                }
            }

            // Step 7: Validate Total Recurring Reimbursement
            WebElement totalReimbursement = driver.findElement(By.id("total-recurring-reimbursement"));
            assert totalReimbursement.getText().equals("$110700");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the WebDriver
            driver.quit();
        }
	}

}
